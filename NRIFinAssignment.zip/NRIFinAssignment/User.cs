﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRIFinAssignment
{
    public class User
    {
        public string login { get; set; }
        public int id { get; set; }
    }
}
