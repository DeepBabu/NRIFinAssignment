﻿
namespace NRIFinAssignment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grdDisplay = new System.Windows.Forms.DataGridView();
            this.lblError = new System.Windows.Forms.Label();
            this.grdContents = new System.Windows.Forms.DataGridView();
            this.lblRepoFiles = new System.Windows.Forms.Label();
            this.txtGitLogin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNotification = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdDisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdContents)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(208, 88);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtToken
            // 
            this.txtToken.Location = new System.Drawing.Point(208, 21);
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(397, 23);
            this.txtToken.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Token";
            // 
            // grdDisplay
            // 
            this.grdDisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDisplay.Location = new System.Drawing.Point(208, 132);
            this.grdDisplay.Name = "grdDisplay";
            this.grdDisplay.RowTemplate.Height = 25;
            this.grdDisplay.Size = new System.Drawing.Size(480, 127);
            this.grdDisplay.TabIndex = 3;
            this.grdDisplay.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdDisplay_CellContentClick);
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(300, 92);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(45, 15);
            this.lblError.TabIndex = 4;
            this.lblError.Text = "lblError";
            // 
            // grdContents
            // 
            this.grdContents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdContents.Location = new System.Drawing.Point(208, 332);
            this.grdContents.Name = "grdContents";
            this.grdContents.RowTemplate.Height = 25;
            this.grdContents.Size = new System.Drawing.Size(397, 168);
            this.grdContents.TabIndex = 5;
            // 
            // lblRepoFiles
            // 
            this.lblRepoFiles.AutoSize = true;
            this.lblRepoFiles.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRepoFiles.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblRepoFiles.Location = new System.Drawing.Point(208, 296);
            this.lblRepoFiles.Name = "lblRepoFiles";
            this.lblRepoFiles.Size = new System.Drawing.Size(0, 21);
            this.lblRepoFiles.TabIndex = 6;
            // 
            // txtGitLogin
            // 
            this.txtGitLogin.Location = new System.Drawing.Point(208, 50);
            this.txtGitLogin.Name = "txtGitLogin";
            this.txtGitLogin.Size = new System.Drawing.Size(100, 23);
            this.txtGitLogin.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(106, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Git Login";
            // 
            // lblNotification
            // 
            this.lblNotification.AutoSize = true;
            this.lblNotification.Location = new System.Drawing.Point(324, 53);
            this.lblNotification.Name = "lblNotification";
            this.lblNotification.Size = new System.Drawing.Size(148, 15);
            this.lblNotification.TabIndex = 9;
            this.lblNotification.Text = "( All Inputs are Mandatory)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 512);
            this.Controls.Add(this.lblNotification);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtGitLogin);
            this.Controls.Add(this.lblRepoFiles);
            this.Controls.Add(this.grdContents);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.grdDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtToken);
            this.Controls.Add(this.btnLogin);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.grdDisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdContents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grdDisplay;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.DataGridView grdContents;
        private System.Windows.Forms.Label lblRepoFiles;
        private System.Windows.Forms.TextBox txtGitLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNotification;
    }
}

