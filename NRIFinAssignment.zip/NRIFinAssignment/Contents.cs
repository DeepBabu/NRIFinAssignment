﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRIFinAssignment
{
    public class Contents
    {
        public string name { get; set; }
        public string path { get; set; }
        public Uri git_url { get; set; } //
        public Uri download_url { get; set; }
    }
}
