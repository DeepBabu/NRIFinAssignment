﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRIFinAssignment
{
    public static class Utility
    {
        public static string token { get; set; }
        public static string loginId { get; set; }


        public const string DotnetRepo = "DotNetRepo";
        public const string CsharpRepo = "CSharpRepo";

        //
        public const string dllExtention = ".dll";
        public const string csExtention = ".cs";

        //public const string baseUrl = "https://api.github.com/repos/MyCustomOrg/";
        //public const string baseReposUrl = "https://api.github.com/orgs/MyCustomOrg/repos";

        public const string mediaTypeHeaderValue = "application/vnd.github.v3+json";
        public const string userAgent = "User-Agent";
        public const string userAgentValue = ".NET Foundation Repository Reporter";
        public const string Authorization = "Authorization";
        public const string Token = "Token ";


        public const string errorInputMsg = "Enter All Mandatory Field(s)";
        public const string userNoAccessonReposMsg = "User Has No Repository to Access Under This Organization";
        public const string grdDisplayRepoName = "Name";
        public const string repofilesDisplayMsg = "Files Under The ";

    }
}
