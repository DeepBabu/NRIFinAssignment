﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;

namespace NRIFinAssignment
{
    public partial class Form1 : Form
    {
        
       
        BAL objBL = new BAL();
        private Object lockObject=new Object();
        public Form1()
        {
            InitializeComponent();
            this.SetVisibility();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtToken.Text.Trim()) || string.IsNullOrEmpty(txtGitLogin.Text.Trim()))
            {
                this.SetVisibility();
                lblError.Text = Utility.errorInputMsg;
                return;
            }
            Utility.token = txtToken.Text.Trim();
            Utility.loginId = txtGitLogin.Text.Trim();
            Task.Run(() => doLogin());
            
        }

        public void SetVisibility()
        {
            txtToken.Text = string.Empty;
            txtGitLogin.Text = string.Empty;
            lblError.Text = string.Empty;
            lblRepoFiles.Text = string.Empty;
            grdDisplay.Visible = false;
            grdContents.Visible = false;
        }

        private async Task doLogin()
        {
            try
            {
                
                var repositories = await objBL.ProcessRepositories();
                if (repositories?.Count > 0)
                {
                    showGrid(repositories);
                }
                else
                {
                    UserNoRepoAccess();
                }
                
            }
            catch (Exception ex)
            {

                if (lblError.InvokeRequired)
                    lblError.Invoke(new Action(() => { lblError.Text = ex.Message; HideGrids(); }));
                else
                {
                    lblError.Text = ex.Message;
                    HideGrids();
                }
            }

        }


        public void UserNoRepoAccess()
        {
            var IsInvokedRequired = grdDisplay.InvokeRequired || lblError.InvokeRequired || grdContents.InvokeRequired;

            if (IsInvokedRequired)
            {
                lblError.Invoke(new Action(() =>
                {
                    lblError.Text = Utility.userNoAccessonReposMsg;
                    HideGrids();

                }));
            }
            else
            {
                HideGrids();
                lblError.Text = Utility.userNoAccessonReposMsg;
            }

        }


        private void HideGrids()
        {
            grdDisplay.Visible = false;
            grdContents.Visible = false;

        }

        private void showGrid(List<Repository> repositories)
        {
            lock (lockObject)
            {
                bool uiMarshal = grdDisplay.InvokeRequired;
                if (uiMarshal)
                {
                    grdDisplay.Invoke(new Action(() => { grdDisplay.DataSource = repositories; grdDisplay.Visible = true;lblError.Text = string.Empty; }));
                }
                else
                {
                    
                    grdDisplay.DataSource = repositories;
                    grdDisplay.Visible = true;
                    lblError.Text = string.Empty;

                }
            }
        }

      

        private void grdDisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(grdDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Value!=null)
            {
                var reponame = grdDisplay.Rows[e.RowIndex].Cells[Utility.grdDisplayRepoName].FormattedValue.ToString();
                Task.Run(() => this.LoadContentGrid(reponame));
            }
        }

        public async Task LoadContentGrid(string reponame)
        {
            var lstContests = await objBL.loadFiles(reponame);
            ShowFiles(lstContests, reponame);
            if (lblRepoFiles.InvokeRequired)
            {
                lblRepoFiles.Invoke(new Action(() =>
                {
                    lblRepoFiles.Text = Utility.repofilesDisplayMsg + reponame;
                    lblRepoFiles.Visible = true;
                }));
            }
            else
            {
                lblRepoFiles.Text = Utility.repofilesDisplayMsg + reponame;
                lblRepoFiles.Visible = true;

            }
            

        }


        public void ShowFiles(List<Contents> lstContents,string reponame)
        {

            switch(reponame)
            {

                case Utility.DotnetRepo:
                    lstContents = lstContents.Where(x => x.name.Contains(Utility.dllExtention)).ToList();
                    break;

                case Utility.CsharpRepo:
                    lstContents = lstContents.Where(x => x.name.Contains(Utility.csExtention)).ToList();
                    break;
            }


            bool uiMarshal = grdContents.InvokeRequired;
            if (uiMarshal)
            {
                grdContents.Invoke(new Action(() => { grdContents.DataSource = lstContents; grdContents.Visible = true; }));
            }
            else
            {
                grdContents.DataSource = lstContents;
                grdContents.Visible = true;

            }
        }
    }
}
