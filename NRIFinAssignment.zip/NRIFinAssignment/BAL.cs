﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace NRIFinAssignment
{
    public class BAL
    {
        private static readonly HttpClient client = new HttpClient();
       
        //private static string tokenValue;   
        public async Task<List<Repository>> ProcessRepositories()
        {
                var repositories = new List<Repository>();
                this.SetupClient();
                var streamTask = client.GetStreamAsync(ConfigurationManager.AppSettings["baseReposUrl"].ToString());
                //var msg = await streamTask;
                repositories = await JsonSerializer.DeserializeAsync<List<Repository>>(await streamTask);

                foreach (var x in repositories)
                {
                    string userapi = ConfigurationManager.AppSettings["baseUrl"].ToString() + x.Name + "/assignees";
                    var streamTaskUserInfo = client.GetStreamAsync(userapi);
                    x.users = await JsonSerializer.DeserializeAsync<List<User>>(await streamTaskUserInfo);
                }

                repositories = repositories.Where(x => x.users.Any(p => p.login == Utility.loginId)).ToList();

            
            
            return repositories;
        }


        public async Task<List<Contents>> loadFiles(string reponame)
        {
            var filesurl = ConfigurationManager.AppSettings["repoFilesUrl"].ToString() + reponame + "/contents";
            SetupClient();
            var streamTask = client.GetStreamAsync(filesurl);
            List<Contents> lstContents = await JsonSerializer.DeserializeAsync<List<Contents>>(await streamTask);
            return lstContents;

        }

        public void SetupClient()
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue(Utility.mediaTypeHeaderValue));
            client.DefaultRequestHeaders.Add(Utility.userAgent, Utility.userAgentValue);
            client.DefaultRequestHeaders.Add(Utility.Authorization, Utility.Token + Utility.token);

        }
    }
}
